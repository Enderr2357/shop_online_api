package com.yly.shop_online.common.constant;

public interface Constant {
    //创建时间
    String CREATE_TIME = "createTime";
    //更新时间
    String UPDATE_TIME= "updateTime";
    //逻辑删除
    String DELETED_FLAG= "deleteFlag";
}
