package com.yly.shop_online.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author ender2357
 * @since 2023-11-09
 */
@RestController
@RequestMapping("/shop_online/userOrderGoods")
public class UserOrderGoodsController {

}
