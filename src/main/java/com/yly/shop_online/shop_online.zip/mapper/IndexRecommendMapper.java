package com.yly.shop_online.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yly.shop_online.entity.IndexRecommend;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ender2357
 * @since 2023-11-09
 */
public interface IndexRecommendMapper extends BaseMapper<IndexRecommend> {

}
